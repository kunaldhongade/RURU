"use strict";
(() => {
var exports = {};
exports.id = 371;
exports.ids = [371];
exports.modules = {

/***/ 7580:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ CreatorDashboard)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "ethers"
var external_ethers_ = __webpack_require__(1982);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "web3modal"
var external_web3modal_ = __webpack_require__(2840);
var external_web3modal_default = /*#__PURE__*/__webpack_require__.n(external_web3modal_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: external "@fortawesome/react-fontawesome"
const react_fontawesome_namespaceObject = require("@fortawesome/react-fontawesome");
// EXTERNAL MODULE: ./config.js
var config = __webpack_require__(3346);
// EXTERNAL MODULE: ./artifacts/contracts/NFTMarket.sol/NFTMarket.json
var NFTMarket = __webpack_require__(8693);
// EXTERNAL MODULE: ./artifacts/contracts/NFT.sol/NFT.json
var NFT = __webpack_require__(1615);
;// CONCATENATED MODULE: ./pages/creator-dashboard.js










function CreatorDashboard() {
    const { 0: nfts , 1: setNfts  } = (0,external_react_.useState)([]);
    const { 0: sold , 1: setSold  } = (0,external_react_.useState)([]);
    const { 0: loadingState , 1: setLoadingState  } = (0,external_react_.useState)("not-loaded");
    (0,external_react_.useEffect)(()=>{
        loadNFTs();
    }, []);
    async function loadNFTs() {
        const web3Modal = new (external_web3modal_default())();
        const connection = await web3Modal.connect();
        const provider = new external_ethers_.ethers.providers.Web3Provider(connection);
        const signer = provider.getSigner();
        const marketContract = new external_ethers_.ethers.Contract(config/* nftmarketaddress */.A, NFTMarket/* abi */.Mt, signer);
        const tokenContract = new external_ethers_.ethers.Contract(config/* nftaddress */.k, NFT/* abi */.Mt, provider);
        const data = await marketContract.fetchItemsCreated();
        const items = await Promise.all(data.map(async (i)=>{
            const tokenUri = await tokenContract.tokenURI(i.tokenId);
            const meta = await external_axios_default().get(tokenUri);
            let price = external_ethers_.ethers.utils.formatUnits(i.price.toString(), "ether");
            let item = {
                price,
                tokenId: i.tokenId.toNumber(),
                seller: i.seller,
                owner: i.owner,
                sold: i.sold,
                image: meta.data.image
            };
            return item;
        }));
        /* create a filtered array of items that have been sold */ const soldItems = items.filter((i)=>i.sold
        );
        setSold(soldItems);
        setNfts(items);
        setLoadingState("loaded");
    }
    if (loadingState === "loaded" && !nfts.length) return /*#__PURE__*/ jsx_runtime_.jsx("h1", {
        className: "py-10 px-20 text-3xl",
        children: "No assets created"
    });
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "p-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl py-2",
                        children: "Items Created"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "relative inline-flex items-center justify-center p-0.5 mb-2 mr-2 overflow-hidden text-sm font-medium text-gray-900 rounded-lg group bg-gradient-to-br from-purple-600 to-blue-500 group-hover:from-purple-600 group-hover:to-blue-500 hover:text-white dark:text-white focus:ring-4 focus:outline-none focus:ring-blue-300 dark:focus:ring-blue-800",
                        onClick: ()=>{
                            window.location.href = "https://testnets.opensea.io/collection/ruru-nft-v2";
                        },
                        type: "button",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            className: "relative px-5 py-2.5 transition-all ease-in duration-75 bg-white dark:bg-gray-900 rounded-md group-hover:bg-opacity-0",
                            children: "opensea"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4",
                        children: nfts.map((nft, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "border shadow rounded-xl overflow-hidden",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: nft.image,
                                        alt: "Picture of the author",
                                        className: "rounded",
                                        width: 363,
                                        height: 350
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-4 bg-black",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "text-2xl font-bold text-white",
                                            children: [
                                                "Price - ",
                                                nft.price,
                                                " Eth"
                                            ]
                                        })
                                    })
                                ]
                            }, i)
                        )
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "px-4",
                children: Boolean(sold.length) && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-2xl py-2",
                            children: "Items sold"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 pt-4",
                            children: sold.map((nft, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "border shadow rounded-xl overflow-hidden",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: nft.image,
                                            alt: "Picture of the author",
                                            className: "rounded",
                                            width: 363,
                                            height: 350
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "p-4 bg-black",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                className: "text-2xl font-bold text-white",
                                                children: [
                                                    "Price - ",
                                                    nft.price,
                                                    " Eth"
                                                ]
                                            })
                                        })
                                    ]
                                }, i)
                            )
                        })
                    ]
                })
            })
        ]
    });
};


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2840:
/***/ ((module) => {

module.exports = require("web3modal");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [686,397,675,759], () => (__webpack_exec__(7580)));
module.exports = __webpack_exports__;

})();