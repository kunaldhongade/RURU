"use strict";
(() => {
var exports = {};
exports.id = 779;
exports.ids = [779];
exports.modules = {

/***/ 4425:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ CreateItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1982);
/* harmony import */ var ethers__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(ethers__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var ipfs_http_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7000);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2840);
/* harmony import */ var web3modal__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(web3modal__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3346);
/* harmony import */ var _artifacts_contracts_NFT_sol_NFT_json__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1615);
/* harmony import */ var _artifacts_contracts_NFTMarket_sol_NFTMarket_json__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8693);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(399);
/* harmony import */ var _ethersproject_providers__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_ethersproject_providers__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_Image__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7047);
/* harmony import */ var next_Image__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_Image__WEBPACK_IMPORTED_MODULE_9__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([ipfs_http_client__WEBPACK_IMPORTED_MODULE_3__]);
ipfs_http_client__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const client = (0,ipfs_http_client__WEBPACK_IMPORTED_MODULE_3__.create)("https://ipfs.infura.io:5001/api/v0");





function CreateItem() {
    const { 0: fileUrl , 1: setFileUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { 0: formInput , 1: updateFormInput  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        price: "",
        name: "",
        description: ""
    });
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    async function onChange(e) {
        const file = e.target.files[0];
        try {
            const added = await client.add(file, {
                progress: (prog)=>console.log(`received: ${prog}`)
            });
            //file saved in the url path below
            const url = `https://ipfs.infura.io/ipfs/${added.path}`;
            setFileUrl(url);
        } catch (e1) {
            console.log("Error uploading file: ", e1);
        }
    }
    //1. create item (image/video) and upload to ipfs
    async function createItem() {
        const { name , description , price  } = formInput; //get the value from the form input
        //form validation
        if (!name || !description || !price || !fileUrl) {
            return;
        }
        const data = JSON.stringify({
            name,
            description,
            image: fileUrl
        });
        try {
            const added = await client.add(data);
            const url = `https://ipfs.infura.io/ipfs/${added.path}`;
            //pass the url to sav eit on Polygon adter it has been uploaded to IPFS
            createSale(url);
        } catch (error) {
            console.log(`Error uploading file: `, error);
        }
    }
    //2. List item for sale
    async function createSale(url) {
        const web3Modal = new (web3modal__WEBPACK_IMPORTED_MODULE_5___default())();
        const connection = await web3Modal.connect();
        const provider = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.providers.Web3Provider(connection);
        //sign the transaction
        const signer = provider.getSigner();
        let contract = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.Contract(_config__WEBPACK_IMPORTED_MODULE_10__/* .nftaddress */ .k, _artifacts_contracts_NFT_sol_NFT_json__WEBPACK_IMPORTED_MODULE_6__/* .abi */ .Mt, signer);
        let transaction = await contract.createToken(url);
        let tx = await transaction.wait();
        //get the tokenId from the transaction that occured above
        //there events array that is returned, the first item from that event
        //is the event, third item is the token id.
        console.log("Transaction: ", tx);
        console.log("Transaction events: ", tx.events[0]);
        let event = tx.events[0];
        let value = event.args[2];
        let tokenId = value.toNumber() //we need to convert it a number
        ;
        //get a reference to the price entered in the form 
        const price = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.utils.parseUnits(formInput.price, "ether");
        contract = new ethers__WEBPACK_IMPORTED_MODULE_2__.ethers.Contract(_config__WEBPACK_IMPORTED_MODULE_10__/* .nftmarketaddress */ .A, _artifacts_contracts_NFTMarket_sol_NFTMarket_json__WEBPACK_IMPORTED_MODULE_7__/* .abi */ .Mt, signer);
        //get the listing price
        let listingPrice = await contract.getListingPrice();
        listingPrice = listingPrice.toString();
        transaction = await contract.createMarketItem(_config__WEBPACK_IMPORTED_MODULE_10__/* .nftaddress */ .k, tokenId, price, {
            value: listingPrice
        });
        await transaction.wait();
        router.push("/");
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "flex justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "w-1/2 flex flex-col pb-12",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: "Asset Name",
                    className: "mt-8 border rounded p-4",
                    onChange: (e)=>updateFormInput({
                            ...formInput,
                            name: e.target.value
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                    placeholder: "Asset description",
                    className: "mt-2 border rounded p-4",
                    onChange: (e)=>updateFormInput({
                            ...formInput,
                            description: e.target.value
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    placeholder: "Asset Price in Eth",
                    className: "mt-8 border rounded p-4",
                    type: "number",
                    onChange: (e)=>updateFormInput({
                            ...formInput,
                            price: e.target.value
                        })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "file",
                    name: "Asset",
                    className: "my-4",
                    onChange: onChange
                }),
                fileUrl && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_Image__WEBPACK_IMPORTED_MODULE_9___default()), {
                    src: fileUrl,
                    alt: "Picture of the author",
                    className: "rounded mt-4",
                    width: 350,
                    height: 500
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    onClick: createItem,
                    className: "font-bold mt-4 bg-pink-500 text-white rounded p-4 shadow-lg",
                    children: "Create NFT"
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 399:
/***/ ((module) => {

module.exports = require("@ethersproject/providers");

/***/ }),

/***/ 1982:
/***/ ((module) => {

module.exports = require("ethers");

/***/ }),

/***/ 7047:
/***/ ((module) => {

module.exports = require("next/Image");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 2840:
/***/ ((module) => {

module.exports = require("web3modal");

/***/ }),

/***/ 7000:
/***/ ((module) => {

module.exports = import("ipfs-http-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [759], () => (__webpack_exec__(4425)));
module.exports = __webpack_exports__;

})();